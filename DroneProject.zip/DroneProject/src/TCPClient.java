
import java.net.*;
import java.io.*;
import java.util.Scanner;

public class TCPClient {

    public static void main(String args[]) {
        Socket s = null;
        try {
            int serverPort = 8888;
            s = new Socket("localhost", serverPort);
            ObjectInputStream in = null;
            ObjectOutputStream out = null;
            out = new ObjectOutputStream(s.getOutputStream());
            in = new ObjectInputStream(s.getInputStream());
            Drone drone = new Drone();
            Scanner scanner_one = new Scanner(System.in);

            out.writeObject(drone);
            System.out.println("Enter Drone ID:");
            String droneID = scanner_one.nextLine();
            System.out.println("Enter Drone Name:");
            String droneName = scanner_one.nextLine();
            System.out.println("Set Position X:");
            String PositionX = scanner_one.nextLine();
            System.out.println("Set Position Y:");
            String PositionY = scanner_one.nextLine();
            drone.setDroneID(droneID);
            drone.setDroneName(droneName);
            drone.setPositionX(PositionX);
            drone.setPositionY(PositionY);
            System.out.println("The Sent Drone Object:");
            System.out.println(drone);
//            Drone drone1 = (Drone) in.readObject();
            out.writeObject(drone);
//            System.out.println("The Received Drone Object:");
//            System.out.println(drone);
        } catch (UnknownHostException e) {
            System.out.println("Socket:" + e.getMessage());
        } catch (EOFException e) {
            System.out.println("EOF:" + e.getMessage());
        } catch (IOException e) {
            System.out.println("readline:" + e.getMessage());
//        } catch (ClassNotFoundException ex) {
//            ex.printStackTrace();
        } finally {
            if (s != null)          try {
                s.close();
            } catch (IOException e) {
                System.out.println("close:" + e.getMessage());
            }
        }
    }
}
